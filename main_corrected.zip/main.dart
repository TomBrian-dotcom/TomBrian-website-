import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:app_links/app_links.dart';

const String tombrianRedirectUrl = 'tombrian://login-callback';
const String tombrianInviteScheme = 'https://tombrian-dotcom.github.io/TomBrian-website-/signup.html?ref=';

// Used so a referral link can open the Create Account screen when the
// TomBrian app is already running. Cold-start referral links are handled
// by LoginGate after the pending referral code has been saved.
final GlobalKey<NavigatorState> tombrianNavigatorKey =
    GlobalKey<NavigatorState>();

class ReferralService {
  static const _storage = FlutterSecureStorage();
  static const _pendingReferralKey = 'tombrian_pending_referral';

  static String referralCodeForUser(String userId) {
    final clean = userId.replaceAll('-', '').toUpperCase();
    return 'TB${clean.substring(0, clean.length >= 8 ? 8 : clean.length)}';
  }

  static String inviteLink(String referralCode) {
    final clean = referralCode.trim().toUpperCase();
    return '$tombrianInviteScheme${Uri.encodeQueryComponent(clean)}';
  }

  static Future<String?> getPendingReferral() async {
    final value = await _storage.read(key: _pendingReferralKey);
    final code = value?.trim().toUpperCase();
    return code == null || code.isEmpty ? null : code;
  }

  static Future<void> savePendingReferral(String code) async {
    final clean = code.trim().toUpperCase();
    if (clean.isEmpty) return;
    await _storage.write(key: _pendingReferralKey, value: clean);
  }

  static Future<void> clearPendingReferral() async {
    await _storage.delete(key: _pendingReferralKey);
  }

  static Future<void> captureUri(Uri uri) async {
    final code = uri.queryParameters['ref']?.trim().toUpperCase();
    if (code == null || code.isEmpty) return;
    await savePendingReferral(code);
  }

  static Future<String> ensureReferralCode() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      throw AuthException('Please log in first.');
    }

    final client = Supabase.instance.client;
    final profile = await client
        .from('profiles')
        .select('referral_code')
        .eq('id', user.id)
        .maybeSingle();

    final existing = profile?['referral_code']?.toString().trim();
    if (existing != null && existing.isNotEmpty) {
      return existing.toUpperCase();
    }

    final code = referralCodeForUser(user.id);

    await client.from('profiles').upsert(
      {
        'id': user.id,
        'referral_code': code,
        'updated_at': DateTime.now().toIso8601String(),
      },
      onConflict: 'id',
    );

    return code;
  }

  static Future<void> claimPendingReferral() async {
    final code = await getPendingReferral();
    final user = Supabase.instance.client.auth.currentUser;
    if (code == null || user == null) return;

    try {
      await Supabase.instance.client.rpc(
        'claim_referral',
        params: {
          'p_referral_code': code,
        },
      );
      await clearPendingReferral();
    } catch (_) {
      // Keep the pending code if the database is temporarily unavailable.
      // It can be claimed on the next successful login.
    }
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final appLinks = AppLinks();
  try {
    final initialUri = await appLinks.getInitialLink();
    if (initialUri != null) {
      await ReferralService.captureUri(initialUri);
    }
  } catch (_) {}

  appLinks.uriLinkStream.listen((uri) async {
    await ReferralService.captureUri(uri);

    // If a new customer taps a referral link while TomBrian is already
    // running, take them directly to Create Account.
    if (Supabase.instance.client.auth.currentUser == null) {
      final code = await ReferralService.getPendingReferral();
      final navigator = tombrianNavigatorKey.currentState;

      if (code != null &&
          code.isNotEmpty &&
          navigator != null) {
        navigator.push(
          MaterialPageRoute(
            builder: (_) => const SignUpPage(),
          ),
        );
      }
    }
  });

  await Supabase.initialize(
    url: 'https://ekqhsnzkovzmepxdajtu.supabase.co',
    anonKey: 'sb_publishable_v4DmfQMCBRvJE_dJvgk1og_v6JMXE_r',
  );

  runApp(const TomBrianApp());
}

class TomBrianApp extends StatelessWidget {
  const TomBrianApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TomBrian',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF05070D),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD9A441),
          brightness: Brightness.dark,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF111624),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      navigatorKey: tombrianNavigatorKey,
      home: const LoginGate(),
    );
  }
}

class LoginGate extends StatefulWidget {
  const LoginGate({super.key});

  @override
  State<LoginGate> createState() => _LoginGateState();
}

class _LoginGateState extends State<LoginGate> {
  static const storage = FlutterSecureStorage();

  static const loginFlagKey = 'tombrian_logged_in';
  static const customerRememberKey = 'tombrian_customer_remember';
  static const adminRememberKey = 'tombrian_admin_remember';

  bool checkingRole = true;
  Widget destination = const LoginPage();

  @override
  void initState() {
    super.initState();
    checkSession();
  }

  Future<void> checkSession() async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;

    if (user == null) {
      // A referral link opened the app while no customer is logged in.
      // Send the new customer directly to Create Account instead of Login.
      final pendingReferral = await ReferralService.getPendingReferral();

      if (mounted) {
        setState(() {
          destination = pendingReferral != null &&
                  pendingReferral.isNotEmpty
              ? const SignUpPage()
              : const LoginPage();
          checkingRole = false;
        });
      }
      return;
    }

    try {
      // A verified email can open the app through the deep link with a
      // temporary authenticated session. We deliberately send that user
      // to the normal login screen instead of opening the app directly.
      final loggedInFlag = await storage.read(
        key: loginFlagKey,
      );

      if (loggedInFlag != 'true') {
        await client.auth.signOut();

        if (!mounted) return;

        setState(() {
          destination = const LoginPage();
          checkingRole = false;
        });
        return;
      }

      final profile = await client
          .from('profiles')
          .select('role, agent_approved')
          .eq('id', user.id)
          .maybeSingle();

      final role = profile?['role']?.toString().toLowerCase();
      final agentApproved = profile?['agent_approved'] == true;

      bool rememberLogin;

      if (role == 'admin') {
        final adminRemember = await storage.read(
          key: adminRememberKey,
        );

        // Existing admin behavior remains ON by default.
        rememberLogin = adminRemember != 'false';
      } else {
        final customerRemember = await storage.read(
          key: customerRememberKey,
        );

        // Customer behavior is ON by default unless explicitly disabled.
        rememberLogin = customerRemember != 'false';
      }

      if (!rememberLogin) {
        await client.auth.signOut();
        await storage.delete(key: loginFlagKey);

        if (!mounted) return;

        setState(() {
          destination = role == 'admin'
              ? const AdminLoginPage()
              : const LoginPage();
          checkingRole = false;
        });
        return;
      }

      if (!mounted) return;

      setState(() {
        destination = role == 'admin'
            ? const AdminDashboardPage()
            : role == 'agent' && agentApproved
                ? const AgentDashboardPage()
                : const HomePage();
        checkingRole = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          destination = const LoginPage();
          checkingRole = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return checkingRole
        ? const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          )
        : destination;
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  final pages = const [
    DashboardPage(),
    TransactionsPage(),
    AccountPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: pages[tab],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) {
          setState(() => tab = i);
        },
        backgroundColor: const Color(0xFF0B0E18),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'History',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Account',
          ),
        ],
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final phoneController = TextEditingController();
  final amountController = TextEditingController();

  String network = 'Safaricom';
  String userName = 'TOMBRIAN';

  @override
  void initState() {
    super.initState();
    loadUserName();
  }

  Future<void> loadUserName() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user == null) return;

    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .maybeSingle();

      if (!mounted) return;

      final name = profile?['full_name'];

      if (name != null && name.toString().trim().isNotEmpty) {
        setState(() {
          userName = name.toString().trim();
        });
      }
    } catch (_) {}
  }

  void message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void openPage(Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => page,
      ),
    );
  }

  Future<void> openAgentArea() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      openPage(const AgentPage());
      return;
    }

    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('role, agent_approved')
          .eq('id', user.id)
          .maybeSingle();

      final role = profile?['role']?.toString().toLowerCase();
      final approved = profile?['agent_approved'] == true;

      if (!mounted) return;
      if (role == 'agent' && approved) {
        openPage(const AgentDashboardPage());
      } else {
        openPage(const AgentPage());
      }
    } catch (_) {
      if (!mounted) return;
      openPage(const AgentPage());
    }
  }

  void continuePurchase() {
    final phone = phoneController.text.trim();
    final amount = amountController.text.trim();
    final value = double.tryParse(amount);

    if (phone.isEmpty) {
      return message(
        'Please enter the customer phone number.',
      );
    }

    if (!RegExp(r'^(07|01)\d{8}$').hasMatch(phone)) {
      return message(
        'Please enter a valid Kenyan phone number.',
      );
    }

    if (value == null || value <= 0) {
      return message(
        'Please enter a valid airtime amount.',
      );
    }

    openPage(
      PurchasePage(
        phone: phone,
        amount: amount,
        network: network,
      ),
    );
  }

  @override
  void dispose() {
    phoneController.dispose();
    amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: const Color(0xFF17233D),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.asset(
                    'assets/tombrian_logo.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Icon(
                      Icons.phone_android,
                      size: 32,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'TomBrian',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'Airtime & mobile services',
                      style: TextStyle(
                        color: Colors.white60,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () => openPage(
                  const NotificationsPage(),
                ),
                icon: const Icon(
                  Icons.notifications_none,
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Text(
            'Jambo, $userName 👋',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Ready to grow today?',
            style: TextStyle(
              color: Colors.white60,
              fontSize: 15,
            ),
          ),
          const SizedBox(height: 18),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF17233D),
                  Color(0xFF0D111C),
                ],
              ),
              border: Border.all(
                color: Color(0x44D9A441),
              ),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Available balance',
                  style: TextStyle(
                    color: Colors.white60,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'KES 0.00',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Dream • Work • Achieve',
                  style: TextStyle(
                    color: Color(0xFFD9A441),
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          const Text(
            'Quick actions',
            style: TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ActionCard(
                  icon: Icons.phone_android,
                  title: 'Sell Airtime',
                  onTap: () => openPage(
                    const SellAirtimePage(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ActionCard(
                  icon: Icons.add_card,
                  title: 'Top Up',
                  onTap: () => openPage(
                    const TopUpPage(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: ActionCard(
                  icon: Icons.account_balance_wallet,
                  title: 'Withdraw',
                  onTap: () => openPage(
                    const WithdrawPage(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ActionCard(
                  icon: Icons.person_add_alt_1,
                  title: 'Agent',
                  onTap: openAgentArea,
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          const Text(
            'Sell airtime',
            style: TextStyle(
              fontSize: 19,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          NetworkField(
            value: network,
            onChanged: (v) {
              setState(() => network = v);
            },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: phoneController,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.phone),
              labelText: 'Customer phone number',
              hintText: '07XXXXXXXX',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: amountController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              prefixIcon: Icon(
                Icons.payments_outlined,
              ),
              labelText: 'Airtime amount',
              hintText: 'Enter amount in KES',
              prefixText: 'KES ',
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: FilledButton.icon(
              onPressed: continuePurchase,
              icon: const Icon(Icons.bolt),
              label: const Text(
                'Continue to purchase',
              ),
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

class AgentPage extends StatelessWidget {
  const AgentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Become a TomBrian Agent'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.person_add_alt_1,
                    size: 48,
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Center(
                child: Text(
                  'Become a TomBrian Agent',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Join TomBrian as an agent and grow your business by providing airtime, data and other mobile services to customers.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(height: 28),
              Text(
                'Agent Benefits',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              _agentInfoCard(context, Icons.account_balance_wallet_outlined, 'Earn Commission', 'Earn commissions from eligible transactions and services you provide to customers.'),
              _agentInfoCard(context, Icons.people_outline, 'Serve More Customers', 'Grow your customer base and provide convenient TomBrian services from your business.'),
              _agentInfoCard(context, Icons.trending_up, 'Grow Your Business', 'Use TomBrian services as an additional opportunity to grow your daily business income.'),
              const SizedBox(height: 24),
              Text(
                'Agent Requirements',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              _requirementItem(context, 'You must have an active TomBrian customer account.'),
              _requirementItem(context, 'You should be willing to provide TomBrian services to customers responsibly.'),
              _requirementItem(context, 'You must provide accurate information during the agent application process.'),
              _requirementItem(context, 'Your application will be reviewed before agent activation.'),
              const SizedBox(height: 28),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.info_outline, color: Theme.of(context).colorScheme.primary),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Applying does not automatically make you a TomBrian Agent. Your application will be reviewed and you will be notified of the application outcome.',
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                 onPressed: () {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => const AgentApplicationPage(),
    ),
  );
},
                  icon: const Icon(Icons.send),
                  label: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 4),
                    child: Text('Apply to Become an Agent', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Center(
                child: Text('TomBrian Agent Program', style: Theme.of(context).textTheme.bodySmall),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _agentInfoCard(BuildContext context, IconData icon, String title, String description) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 30, color: Theme.of(context).colorScheme.primary),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  Text(description),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _requirementItem(BuildContext context, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.check_circle_outline, size: 22, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: Theme.of(context).textTheme.bodyMedium)),
        ],
      ),
    );
  }
}


class AgentApplicationPage extends StatefulWidget {
  const AgentApplicationPage({super.key});

  @override
  State<AgentApplicationPage> createState() => _AgentApplicationPageState();
}

class _AgentApplicationPageState extends State<AgentApplicationPage> {
  final fullNameController = TextEditingController();
  final phoneController = TextEditingController();
  final reasonController = TextEditingController();

  bool loading = true;
  bool submitting = false;
  bool agreedToTerms = false;
  String? status;
  String adminNotes = '';

  @override
  void initState() {
    super.initState();
    loadApplication();
  }

  @override
  void dispose() {
    fullNameController.dispose();
    phoneController.dispose();
    reasonController.dispose();
    super.dispose();
  }

  Future<void> loadApplication() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) { if (mounted) setState(() => loading = false); return; }
    try {
      final profile = await Supabase.instance.client
          .from('profiles')
          .select('full_name, phone, role, agent_approved')
          .eq('id', user.id)
          .maybeSingle();

      // If the admin has approved this account as an agent,
      // take the user directly to the Agent Dashboard.
      if (profile?['role']?.toString().toLowerCase() == 'agent' &&
          profile?['agent_approved'] == true) {
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const AgentDashboardPage()),
          (_) => false,
        );
        return;
      }

      final application = await Supabase.instance.client.from('agent_applications').select(
        'id, full_name, phone, reason, terms_agreed, status, admin_notes, created_at, updated_at',
      ).eq('user_id', user.id).order('created_at', ascending: false).limit(1).maybeSingle();
      if (!mounted) return;
      setState(() {
        fullNameController.text = (profile?['full_name'] ?? application?['full_name'] ?? '').toString();
        phoneController.text = (profile?['phone'] ?? application?['phone'] ?? '').toString();
        reasonController.text = (application?['reason'] ?? '').toString();
        agreedToTerms = application?['terms_agreed'] == true;
        status = application?['status']?.toString().toLowerCase();
        adminNotes = (application?['admin_notes'] ?? '').toString();
        loading = false;
      });
    } catch (e) {
      if (mounted) { setState(() => loading = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not load application: $e'))); }
    }
  }

  Future<void> submitApplication() async {
    if (submitting) return;
    final user = Supabase.instance.client.auth.currentUser;
    final fullName = fullNameController.text.trim();
    final phone = phoneController.text.trim();
    final reason = reasonController.text.trim();
    if (user == null) return;
    if (fullName.isEmpty || phone.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please complete your profile name and phone number first.'))); return; }
    if (reason.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please tell us why you want to become a TomBrian Agent.'))); return; }
    if (!agreedToTerms) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please agree to the Agent Terms before submitting.'))); return; }
    if (status == 'pending' || status == 'approved') return;

    setState(() => submitting = true);
    try {
      await Supabase.instance.client.from('agent_applications').insert({
        'user_id': user.id,
        'full_name': fullName,
        'phone': phone,
        'reason': reason,
        'terms_agreed': true,
        'status': 'pending',
      });
      if (!mounted) return;
      setState(() { status = 'pending'; submitting = false; adminNotes = ''; });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Application submitted successfully.')));
    } catch (e) {
      if (mounted) { setState(() => submitting = false); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not submit application: $e'))); }
    }
  }

  Widget statusBanner() {
    final s = status;
    if (s == null || s.isEmpty) return const SizedBox.shrink();
    final approved = s == 'approved';
    final rejected = s == 'rejected';
    final title = approved ? 'Application Approved' : rejected ? 'Application Rejected' : 'Application Pending';
    final text = approved ? 'Your agent application has been approved. TomBrian will provide the next activation instructions.' : rejected ? (adminNotes.isEmpty ? 'Your application was not approved at this time.' : adminNotes) : 'Your application is under review. You do not need to submit another application while it is pending.';
    return Card(color: Colors.white.withOpacity(0.04), child: Padding(padding: const EdgeInsets.all(16), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(approved ? Icons.check_circle_outline : rejected ? Icons.cancel_outlined : Icons.hourglass_empty, color: approved ? Colors.greenAccent : rejected ? Colors.redAccent : const Color(0xFFD9A441)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), const SizedBox(height: 6), Text(text, style: const TextStyle(color: Colors.white70, height: 1.4))]))])));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final locked = status == 'pending' || status == 'approved';
    return Scaffold(
      appBar: AppBar(title: const Text('Agent Application'), centerTitle: true),
      body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Apply to Become a TomBrian Agent', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Complete the application below. Your profile details are loaded automatically.', style: TextStyle(color: Colors.white70, height: 1.4)),
        const SizedBox(height: 20),
        statusBanner(),
        const SizedBox(height: 20),
        const Text('Your Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        TextField(controller: fullNameController, readOnly: true, decoration: const InputDecoration(prefixIcon: Icon(Icons.person_outline), labelText: 'Full Name')),
        const SizedBox(height: 14),
        TextField(controller: phoneController, readOnly: true, keyboardType: TextInputType.phone, decoration: const InputDecoration(prefixIcon: Icon(Icons.phone_outlined), labelText: 'Phone Number')),
        const SizedBox(height: 24),
        const Text('Why do you want to become a TomBrian Agent?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        TextField(controller: reasonController, readOnly: locked, minLines: 5, maxLines: 8, decoration: const InputDecoration(hintText: 'Tell us why you would like to become a TomBrian Agent...', alignLabelWithHint: true, prefixIcon: Padding(padding: EdgeInsets.only(bottom: 72), child: Icon(Icons.edit_note_outlined))),),
        const SizedBox(height: 20),
        Card(color: Colors.white.withOpacity(0.04), child: CheckboxListTile(value: agreedToTerms, onChanged: locked ? null : (v) => setState(() => agreedToTerms = v ?? false), controlAffinity: ListTileControlAffinity.leading, title: const Text('I agree to the TomBrian Agent Terms and understand that my application must be reviewed before I can become an agent.'))),
        const SizedBox(height: 24),
        if (!locked) SizedBox(width: double.infinity, height: 54, child: FilledButton.icon(onPressed: submitting ? null : submitApplication, icon: submitting ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_outlined), label: Text(submitting ? 'Submitting...' : 'Submit Application'))),
        if (locked) SizedBox(width: double.infinity, height: 54, child: OutlinedButton.icon(onPressed: loadApplication, icon: const Icon(Icons.refresh), label: const Text('Refresh Application Status'))),
        const SizedBox(height: 16),
        Center(child: Text(locked ? 'Application status is saved in TomBrian.' : 'Your application will remain pending until TomBrian reviews it.', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12))),
      ]))),
    );
  }
}


class NetworkField extends StatelessWidget {
  final String value;
  final ValueChanged<String> onChanged;

  const NetworkField({
    super.key,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: const InputDecoration(
        prefixIcon: Icon(Icons.network_cell),
        labelText: 'Network',
      ),
      items: const [
        DropdownMenuItem(
          value: 'Safaricom',
          child: Text('Safaricom'),
        ),
        DropdownMenuItem(
          value: 'Airtel',
          child: Text('Airtel'),
        ),
        DropdownMenuItem(
          value: 'Telkom',
          child: Text('Telkom'),
        ),
      ],
      onChanged: (v) {
        if (v != null) {
          onChanged(v);
        }
      },
    );
  }
}

class ActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const ActionCard({
    super.key,
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 120,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF111624),
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          padding: const EdgeInsets.all(18),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 30,
              color: const Color(0xFFD9A441),
            ),
            const SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SellAirtimePage extends StatefulWidget {
  const SellAirtimePage({super.key});

  @override
  State<SellAirtimePage> createState() =>
      _SellAirtimePageState();
}

class _SellAirtimePageState
    extends State<SellAirtimePage> {
  final phoneController = TextEditingController();
  final amountController = TextEditingController();

  String network = 'Safaricom';

  @override
  void dispose() {
    phoneController.dispose();
    amountController.dispose();
    super.dispose();
  }

  void continuePurchase() {
    final phone = phoneController.text.trim();
    final amount = amountController.text.trim();
    final value = double.tryParse(amount);

    if (!RegExp(r'^(07|01)\d{8}$').hasMatch(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid Kenyan phone number.',
          ),
        ),
      );
      return;
    }

    if (value == null || value <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid amount.',
          ),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PurchasePage(
          phone: phone,
          amount: amount,
          network: network,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sell Airtime'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.phone_android,
              size: 65,
              color: Color(0xFFD9A441),
            ),
            const SizedBox(height: 20),
            const Text(
              'Sell Airtime',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Enter the customer details below.',
              style: TextStyle(
                color: Colors.white60,
              ),
            ),
            const SizedBox(height: 24),
            NetworkField(
              value: network,
              onChanged: (v) {
                setState(() => network = v);
              },
            ),
            const SizedBox(height: 14),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.phone),
                labelText: 'Customer phone number',
                hintText: '07XXXXXXXX',
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: amountController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                prefixIcon: Icon(
                  Icons.payments_outlined,
                ),
                labelText: 'Airtime amount',
                hintText: 'Enter amount in KES',
                prefixText: 'KES ',
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton.icon(
                onPressed: continuePurchase,
                icon: const Icon(Icons.arrow_forward),
                label: const Text('Continue'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PurchasePage extends StatelessWidget {
  final String phone;
  final String amount;
  final String network;

  const PurchasePage({
    super.key,
    required this.phone,
    required this.amount,
    required this.network,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Confirm Purchase'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.check_circle_outline,
              size: 70,
              color: Color(0xFFD9A441),
            ),
            const SizedBox(height: 24),
            const Text(
              'Purchase details',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Network: $network',
              style: const TextStyle(
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Customer: $phone',
              style: const TextStyle(
                fontSize: 17,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Amount: KES $amount',
              style: const TextStyle(
                fontSize: 17,
              ),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (dialogContext) =>
                        AlertDialog(
                      title: const Text(
                        'Purchase submitted',
                      ),
                      content: Text(
                        'Airtime request for KES $amount '
                        'to $phone has been submitted.',
                      ),
                      actions: [
                        FilledButton(
                          onPressed: () {
                            Navigator.pop(
                              dialogContext,
                            );
                            Navigator.pop(context);
                          },
                          child: const Text('Done'),
                        ),
                      ],
                    ),
                  );
                },
                child: const Text(
                  'Confirm Purchase',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TopUpPage extends StatelessWidget {
  const TopUpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimpleServicePage(
      title: 'Top Up',
      icon: Icons.add_card,
      description:
          'Add money to your TomBrian balance.',
    );
  }
}

class WithdrawPage extends StatelessWidget {
  const WithdrawPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const SimpleServicePage(
      title: 'Withdraw',
      icon: Icons.account_balance_wallet,
      description:
          'Withdraw money from your TomBrian balance.',
    );
  }
}

class SupportPage extends StatelessWidget {
  const SupportPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TomBrian Support Center'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.white12),
              color: Colors.white.withOpacity(0.04),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.support_agent, size: 42, color: Color(0xFFD9A441)),
                SizedBox(height: 12),
                Text('How can we help you?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                SizedBox(height: 8),
                Text(
                  'Find answers to common questions or choose the support option that best matches your problem.',
                  style: TextStyle(color: Colors.white70, height: 1.45),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Text('Help Center / FAQs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _faq('How do I buy airtime?', 'Open Sell Airtime or Purchase, enter the required phone number and amount, then follow the instructions shown by TomBrian.'),
          _faq('Where can I see my transactions?', 'Open Transactions from the bottom navigation to review the transaction information available on your account.'),
          _faq('What should I do if a transaction has a problem?', 'Use Report a Transaction Problem below and provide the transaction details and a clear description of the issue.'),
          _faq('What if I entered the wrong phone number?', 'Keep the transaction details and report the issue to TomBrian Customer Care as soon as possible. Do not repeat the transaction unless advised.'),
          _faq('I forgot my password. What can I do?', 'Use Forgot Password on the login screen and follow the password reset instructions sent to your registered email address.'),
          _faq('How can I contact TomBrian Customer Care?', 'Use Contact Us in Settings to call, open WhatsApp or send an email. Customer Care hours are 7:00 AM – 9:00 PM.'),
          const SizedBox(height: 20),
          const Text('Need More Help?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          _supportOption(context, Icons.report_problem_outlined, 'Report a Transaction Problem', 'Send a transaction issue to TomBrian Customer Care.', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ReportTransactionProblemPage()))),
          _supportOption(context, Icons.assignment_outlined, 'My Support Requests', 'View your submitted reports and their status.', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MySupportRequestsPage()))),
          _supportOption(context, Icons.chat_outlined, 'Chat / Customer Care', 'Send a message directly to TomBrian Customer Care.', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerCareChatPage()))),
          const SizedBox(height: 20),
          const Center(child: Text('TomBrian • Dream • Work • Achieve', style: TextStyle(color: Colors.white38, fontSize: 12))),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  static Widget _faq(String question, String answer) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      color: Colors.white.withOpacity(0.04),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Colors.white12)),
      child: ExpansionTile(
        leading: const Icon(Icons.help_outline, color: Color(0xFFD9A441)),
        title: Text(question, style: const TextStyle(fontWeight: FontWeight.w600)),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [Text(answer, style: const TextStyle(color: Colors.white70, height: 1.45))],
      ),
    );
  }

  static Widget _supportOption(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      elevation: 0,
      color: Colors.white.withOpacity(0.04),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: Colors.white12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        leading: Icon(icon, color: const Color(0xFFD9A441)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 4), child: Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 13))),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

class ReportTransactionProblemPage extends StatefulWidget {
  const ReportTransactionProblemPage({super.key});
  @override
  State<ReportTransactionProblemPage> createState() => _ReportTransactionProblemPageState();
}

class _ReportTransactionProblemPageState extends State<ReportTransactionProblemPage> {
  final categoryController = TextEditingController();
  final transactionIdController = TextEditingController();
  final descriptionController = TextEditingController();
  bool sending = false;

  @override
  void dispose() {
    categoryController.dispose();
    transactionIdController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please log in again.')));
      return;
    }
    final category = categoryController.text.trim();
    final description = descriptionController.text.trim();
    if (category.isEmpty || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please enter the issue type and describe the problem.')));
      return;
    }
    setState(() => sending = true);
    try {
      await Supabase.instance.client.from('support_requests').insert({
        'user_id': user.id,
        'issue_category': category,
        'description': description,
        'transaction_id': transactionIdController.text.trim(),
        'status': 'Pending',
      });
      if (!mounted) return;
      setState(() => sending = false);
      await showDialog<void>(context: context, builder: (c) => AlertDialog(title: const Text('Report submitted'), content: const Text('Your support request has been sent to TomBrian Customer Care.'), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))]));
      if (mounted) Navigator.pop(context);
    } on PostgrestException catch (e) {
      if (!mounted) return;
      setState(() => sending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not submit report: ${e.message}')));
    } catch (e) {
      if (!mounted) return;
      setState(() => sending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not submit report: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Report a Transaction Problem')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Tell us what went wrong', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Provide as much detail as possible so Customer Care can assist you.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 20),
        TextField(controller: categoryController, decoration: const InputDecoration(labelText: 'Issue type', hintText: 'e.g. Pending transaction, wrong number, failed transaction')),
        const SizedBox(height: 14),
        TextField(controller: transactionIdController, decoration: const InputDecoration(labelText: 'Transaction reference (optional)')),
        const SizedBox(height: 14),
        TextField(controller: descriptionController, minLines: 6, maxLines: 10, decoration: const InputDecoration(labelText: 'Describe the problem', alignLabelWithHint: true)),
        const SizedBox(height: 20),
        SizedBox(height: 54, child: FilledButton.icon(onPressed: sending ? null : submit, icon: sending ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send), label: Text(sending ? 'Sending...' : 'Submit Report'))),
      ]),
    );
  }
}

class MySupportRequestsPage extends StatefulWidget {
  const MySupportRequestsPage({super.key});
  @override
  State<MySupportRequestsPage> createState() => _MySupportRequestsPageState();
}

class _MySupportRequestsPageState extends State<MySupportRequestsPage> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> requests = [];

  @override
  void initState() { super.initState(); loadRequests(); }

  Future<void> loadRequests() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Please log in again.');
      final data = await Supabase.instance.client.from('support_requests').select('id, issue_category, description, transaction_id, status, created_at').eq('user_id', user.id).order('created_at', ascending: false);
      if (!mounted) return;
      setState(() { requests = List<Map<String, dynamic>>.from(data); loading = false; error = null; });
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; error = 'Could not load support requests: $e'; });
    }
  }

  String dateText(dynamic value) { try { return DateTime.parse(value.toString()).toLocal().toString().split('.').first; } catch (_) { return ''; } }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Support Requests'), actions: [IconButton(onPressed: loadRequests, icon: const Icon(Icons.refresh))]),
      body: loading ? const Center(child: CircularProgressIndicator()) : error != null ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(error!, textAlign: TextAlign.center), const SizedBox(height: 14), FilledButton(onPressed: loadRequests, child: const Text('Retry'))]))) : requests.isEmpty ? const Center(child: Text('You have no support requests yet.')) : ListView.builder(padding: const EdgeInsets.all(16), itemCount: requests.length, itemBuilder: (_, i) { final r = requests[i]; return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.report_problem_outlined, color: Color(0xFFD9A441)), const SizedBox(width: 10), Expanded(child: Text((r['issue_category'] ?? 'Support Request').toString(), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))), Text((r['status'] ?? 'Pending').toString(), style: const TextStyle(color: Color(0xFFD9A441), fontWeight: FontWeight.w700))]), const SizedBox(height: 10), Text((r['description'] ?? '').toString(), style: const TextStyle(color: Colors.white70, height: 1.4)), const SizedBox(height: 10), Text('Reference: ${(r['id'] ?? '').toString()}', style: const TextStyle(color: Colors.white54, fontSize: 12)), Text('Transaction: ${(r['transaction_id'] ?? '').toString()}', style: const TextStyle(color: Colors.white54, fontSize: 12)), Text('Submitted: ${dateText(r['created_at'])}', style: const TextStyle(color: Colors.white54, fontSize: 12))]))); })
    );
  }
}

class CustomerCareChatPage extends StatefulWidget {
  const CustomerCareChatPage({super.key});
  @override
  State<CustomerCareChatPage> createState() => _CustomerCareChatPageState();
}

class _CustomerCareChatPageState extends State<CustomerCareChatPage> {
  final messageController = TextEditingController();
  final scrollController = ScrollController();
  bool loading = true;
  bool sending = false;
  String? error;
  List<Map<String, dynamic>> messages = [];

  @override
  void initState() { super.initState(); loadMessages(); }
  @override
  void dispose() { messageController.dispose(); scrollController.dispose(); super.dispose(); }

  Future<void> loadMessages() async {
    try {
      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) throw Exception('Please log in again to use Customer Care chat.');
      final data = await Supabase.instance.client.from('support_chat_messages').select('id, sender_type, message, created_at').eq('user_id', user.id).order('created_at', ascending: true);
      if (!mounted) return;
      setState(() { messages = List<Map<String, dynamic>>.from(data); loading = false; error = null; });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() { loading = false; error = 'Could not load Customer Care chat: $e'; });
    }
  }

  void _scrollToBottom() { WidgetsBinding.instance.addPostFrameCallback((_) { if (scrollController.hasClients) scrollController.animateTo(scrollController.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut); }); }

  Future<void> sendMessage() async {
    final text = messageController.text.trim();
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null || text.isEmpty || sending) return;
    setState(() => sending = true);
    try {
      final result = await Supabase.instance.client.from('support_chat_messages').insert({'user_id': user.id, 'sender_type': 'customer', 'message': text}).select('id, sender_type, message, created_at').single();
      if (!mounted) return;
      setState(() { messages.add(Map<String, dynamic>.from(result)); messageController.clear(); sending = false; });
      _scrollToBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() => sending = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not send message: $e')));
    }
  }

  String timeText(dynamic value) { try { final d = DateTime.parse(value.toString()).toLocal(); return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}'; } catch (_) { return ''; } }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Chat / Customer Care'), actions: [IconButton(onPressed: loadMessages, icon: const Icon(Icons.refresh))]),
      body: Column(children: [
        Container(width: double.infinity, padding: const EdgeInsets.all(16), color: Colors.white.withOpacity(0.04), child: const Row(children: [CircleAvatar(child: Icon(Icons.support_agent)), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('TomBrian Customer Care', style: TextStyle(fontWeight: FontWeight.w700)), SizedBox(height: 3), Text('Customer Care hours: 7:00 AM – 9:00 PM', style: TextStyle(color: Colors.white60, fontSize: 12))]))])),
        Expanded(child: loading ? const Center(child: CircularProgressIndicator()) : error != null ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(error!, textAlign: TextAlign.center), const SizedBox(height: 14), FilledButton(onPressed: loadMessages, child: const Text('Retry'))]))) : messages.isEmpty ? const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('Start a conversation with TomBrian Customer Care.\n\nTell us how we can help you.', textAlign: TextAlign.center))) : ListView.builder(controller: scrollController, padding: const EdgeInsets.all(16), itemCount: messages.length, itemBuilder: (_, i) { final m = messages[i]; final mine = (m['sender_type'] ?? 'customer') == 'customer'; return Align(alignment: mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(constraints: const BoxConstraints(maxWidth: 320), margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: mine ? const Color(0xFF17233D) : Colors.white.withOpacity(0.06), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white12)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text((m['message'] ?? '').toString()), const SizedBox(height: 4), Text(timeText(m['created_at']), style: const TextStyle(color: Colors.white38, fontSize: 11))]))); }),),
        SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 12), child: Row(children: [Expanded(child: TextField(controller: messageController, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Type your message...'))), const SizedBox(width: 8), IconButton(onPressed: sending ? null : sendMessage, icon: const Icon(Icons.send))]))),
      ]),
    );
  }
}

class SimpleServicePage extends StatelessWidget {
  final String title;
  final String description;
  final IconData icon;

  const SimpleServicePage({
    super.key,
    required this.title,
    required this.icon,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment:
                MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 70,
                color: const Color(0xFFD9A441),
              ),
              const SizedBox(height: 20),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                description,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white60,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 30),
              FilledButton(
                onPressed: () {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(
                    SnackBar(
                      content: Text(
                        '$title button is working.',
                      ),
                    ),
                  );
                },
                child: const Text('Continue'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
      body: const Center(
        child: Column(
          mainAxisAlignment:
              MainAxisAlignment.center,
          children: [
            Icon(
              Icons.notifications_none,
              size: 70,
              color: Color(0xFFD9A441),
            ),
            SizedBox(height: 20),
            Text(
              'No new notifications',
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transaction History'),
      ),
      body: Center(
        child: FilledButton(
          onPressed: () {
            ScaffoldMessenger.of(context)
                .showSnackBar(
              const SnackBar(
                content: Text(
                  'No transactions yet.',
                ),
              ),
            );
          },
          child: const Text('Refresh'),
        ),
      ),
    );
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  Future<void> _logout(
    BuildContext context,
  ) async {
    final shouldLogout =
        await showDialog<bool>(
      context: context,
      builder: (dialogContext) =>
          AlertDialog(
        title: const Text(
          'Log out of TomBrian?',
        ),
        content: const Text(
          'Are you sure you want to log out?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(
              dialogContext,
              false,
            ),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(
              dialogContext,
              true,
            ),
            child: const Text('Log Out'),
          ),
        ],
      ),
    );

    if (shouldLogout != true) return;

    try {
      await Supabase.instance.client.auth
          .signOut();

      await _clearLoginFlag();

      if (!context.mounted) return;

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => const LoginPage(),
        ),
        (_) => false,
      );
    } on AuthException catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Could not log out: ${e.message}',
            ),
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Could not log out: $e',
            ),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const CircleAvatar(
            radius: 42,
            child: Icon(
              Icons.person,
              size: 45,
            ),
          ),
          const SizedBox(height: 16),
          const Center(
            child: Text(
              'TomBrian User',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 30),
          ListTile(
            leading: const Icon(
              Icons.person_outline,
            ),
            title: const Text('Profile'),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const ProfilePage(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.group_add_outlined,
            ),
            title: const Text('Invite Friends'),
            subtitle: const Text(
              'Share your TomBrian invite link and grow your network',
              style: TextStyle(
                color: Colors.white60,
                fontSize: 13,
              ),
            ),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => const ReferralPage(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.settings_outlined,
            ),
            title: const Text('Settings'),
            subtitle: const Text(
              'Manage your account and app preferences',
              style: TextStyle(
                color: Colors.white60,
                fontSize: 13,
              ),
            ),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const SettingsPage(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.help_outline,
            ),
            title: const Text('Help'),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const SupportPage(),
              ),
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.info_outline,
            ),
            title: const Text('About TomBrian'),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'TomBrian',
              applicationVersion: '1.0.0',
              applicationLegalese:
                  'Dream • Work • Achieve',
            ),
          ),
          ListTile(
            leading: const Icon(
              Icons.logout,
            ),
            title: const Text('Log Out'),
            trailing: const Icon(
              Icons.chevron_right,
            ),
            onTap: () => _logout(context),
          ),
        ],
      ),
    );
  }
}

class ReferralPage extends StatefulWidget {
  const ReferralPage({super.key});

  @override
  State<ReferralPage> createState() => _ReferralPageState();
}

class _ReferralPageState extends State<ReferralPage> {
  String? referralCode;
  int referralCount = 0;
  bool loading = true;
  bool sharing = false;

  String get inviteLink {
    final code = referralCode?.trim();
    if (code == null || code.isEmpty) return '';
    return ReferralService.inviteLink(code);
  }

  @override
  void initState() {
    super.initState();
    loadReferral();
  }

  Future<void> loadReferral() async {
    final user = Supabase.instance.client.auth.currentUser;

    if (user == null) {
      if (mounted) setState(() => loading = false);
      return;
    }

    try {
      // Every authenticated TomBrian customer gets a referral code.
      // Existing codes are reused; missing codes are created in profiles.
      final code = await ReferralService.ensureReferralCode();

      final referrals = await Supabase.instance.client
          .from('referrals')
          .select('id')
          .eq('referrer_id', user.id);

      if (!mounted) return;

      setState(() {
        referralCode = code.trim().toUpperCase();
        referralCount = (referrals as List).length;
        loading = false;
      });
    } catch (e) {
      // Do not leave the invite section blank if the referral-count query
      // temporarily fails. Try to recover the code directly from the profile.
      try {
        final profile = await Supabase.instance.client
            .from('profiles')
            .select('referral_code')
            .eq('id', user.id)
            .maybeSingle();

        final stored = profile?['referral_code']?.toString().trim().toUpperCase();

        if (stored != null && stored.isNotEmpty) {
          if (!mounted) return;
          setState(() {
            referralCode = stored;
            loading = false;
          });
          return;
        }
      } catch (_) {}

      if (!mounted) return;
      setState(() => loading = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load invite link: $e')),
      );
    }
  }

  Future<void> copyLink() async {
    final link = inviteLink;
    if (link.isEmpty) return;

    await Clipboard.setData(ClipboardData(text: link));

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Invite link copied.')),
    );
  }

  Future<void> shareOnWhatsApp() async {
    final link = inviteLink;
    if (link.isEmpty || sharing) return;

    setState(() => sharing = true);

    final message = Uri.encodeComponent(
      'Join me on TomBrian. Create your account using my invite link:\n$link',
    );
    final uri = Uri.parse('https://wa.me/?text=$message');

    try {
      final opened = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
      );

      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open WhatsApp.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not share invite link: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => sharing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final link = inviteLink;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Invite Friends'),
        centerTitle: true,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      gradient: const LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          Color(0xFF17233D),
                          Color(0xFF0D111C),
                        ],
                      ),
                      border: Border.all(
                        color: const Color(0x44D9A441),
                      ),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          Icons.group_add_outlined,
                          size: 42,
                          color: Color(0xFFD9A441),
                        ),
                        SizedBox(height: 14),
                        Text(
                          'Invite people to TomBrian',
                          style: TextStyle(
                            fontSize: 23,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Every TomBrian customer has a personal invite link. Share yours with friends and family.',
                          style: TextStyle(
                            color: Colors.white70,
                            height: 1.45,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Your referral code',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            referralCode ?? 'Unavailable',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 18),
                          const Text(
                            'Your invite link',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFF111624),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: SelectableText(
                              link.isEmpty ? 'Unavailable' : link,
                              style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: link.isEmpty ? null : copyLink,
                          icon: const Icon(Icons.copy_outlined),
                          label: const Text('Copy Link'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed:
                              link.isEmpty || sharing ? null : shareOnWhatsApp,
                          icon: sharing
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.chat_outlined),
                          label: const Text('WhatsApp'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Card(
                    child: ListTile(
                      leading: const Icon(
                        Icons.people_outline,
                        color: Color(0xFFD9A441),
                      ),
                      title: const Text('People referred'),
                      subtitle: const Text(
                        'Customers who registered through your invite link.',
                      ),
                      trailing: Text(
                        '$referralCount',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'How it works',
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    '1. Share your personal link.\n'
                    '2. Your friend opens it and creates a TomBrian account.\n'
                    '3. TomBrian records the referral to your account.\n'
                    '4. Your referral history updates automatically.',
                    style: TextStyle(
                      color: Colors.white70,
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class TermsAndConditionsPage extends StatelessWidget {
  const TermsAndConditionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Terms & Conditions')), body: ListView(padding: const EdgeInsets.all(20), children: const [
      Text('TomBrian Terms & Conditions', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
      SizedBox(height: 8),
      Text('Please read these terms before using TomBrian services.', style: TextStyle(color: Colors.white60)),
      SizedBox(height: 24),
      Text('1. Use of the service', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('You agree to provide accurate account information and use TomBrian only for lawful transactions. Keep your login details private and do not allow unauthorized people to use your account.'),
      SizedBox(height: 18),
      Text('2. Transactions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('Always confirm the recipient phone number, network and amount before completing a transaction. Keep transaction references for your records and contact Customer Care promptly when a problem occurs.'),
      SizedBox(height: 18),
      Text('3. Account security', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('You are responsible for activity carried out through your account. If you suspect unauthorized access, change your password and contact TomBrian Customer Care.'),
      SizedBox(height: 18),
      Text('4. Agent applications', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('Submitting an agent application does not automatically make you a TomBrian Agent. Applications are reviewed and approval is required before agent activation.'),
      SizedBox(height: 18),
      Text('5. Support', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
      SizedBox(height: 8),
      Text('For help, use the TomBrian Support Center or Contact Us options in Settings. Customer Care hours are 7:00 AM – 9:00 PM.'),
      SizedBox(height: 24),
      Text('TomBrian • Dream • Work • Achieve', style: TextStyle(color: Colors.white38, fontSize: 12)),
    ]));
  }
}

class AboutTomBrianPage extends StatelessWidget {
  const AboutTomBrianPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('About TomBrian')), body: ListView(padding: const EdgeInsets.all(20), children: [
      Center(child: Container(width: 100, height: 100, decoration: BoxDecoration(color: const Color(0xFF17233D), borderRadius: BorderRadius.circular(24)), child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/tombrian_logo.jpg', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.phone_android, size: 52, color: Color(0xFFD9A441)))))),
      const SizedBox(height: 20),
      const Center(child: Text('TomBrian', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800))),
      const SizedBox(height: 6),
      const Center(child: Text('Airtime & mobile services', style: TextStyle(color: Colors.white60))),
      const SizedBox(height: 24),
      Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('About the app', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        SizedBox(height: 10),
        Text('TomBrian is a customer-focused platform for convenient airtime, mobile service and account management. The app brings your services, transactions, support and account settings together in one place.', style: TextStyle(color: Colors.white70, height: 1.5)),
        SizedBox(height: 16),
        Text('Our goal', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
        SizedBox(height: 10),
        Text('To make everyday mobile services simple, accessible and dependable for TomBrian customers and agents.', style: TextStyle(color: Colors.white70, height: 1.5)),
      ]))),
      const SizedBox(height: 16),
      const ListTile(leading: Icon(Icons.verified_outlined, color: Color(0xFFD9A441)), title: Text('Version'), subtitle: Text('1.0.0')),
      const ListTile(leading: Icon(Icons.schedule_outlined, color: Color(0xFFD9A441)), title: Text('Customer Care'), subtitle: Text('7:00 AM – 9:00 PM')),
      const SizedBox(height: 12),
      const Center(child: Text('Dream • Work • Achieve', style: TextStyle(color: Color(0xFFD9A441), letterSpacing: 1.2))),
    ]));
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() =>
      _SettingsPageState();
}

class _SettingsPageState
    extends State<SettingsPage> {
  static const storage = FlutterSecureStorage();

  static const rememberLoginKey =
      'tombrian_customer_remember';

  static const transactionNotificationsKey =
      'tombrian_transaction_notifications';

  static const accountAlertsKey =
      'tombrian_account_alerts';

  static const promotionsKey =
      'tombrian_promotions_notifications';

  static const loginFlagKey =
      'tombrian_logged_in';

  bool loading = true;
  bool rememberLogin = true;
  bool transactionNotifications = true;
  bool accountAlerts = true;
  bool promotions = false;

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    try {
      final remember = await storage.read(
        key: rememberLoginKey,
      );

      final transactions =
          await storage.read(
        key: transactionNotificationsKey,
      );

      final alerts = await storage.read(
        key: accountAlertsKey,
      );

      final promotion = await storage.read(
        key: promotionsKey,
      );

      if (!mounted) return;

      setState(() {
        rememberLogin = remember != 'false';
        transactionNotifications =
            transactions != 'false';
        accountAlerts = alerts != 'false';
        promotions = promotion == 'true';
        loading = false;
      });
    } catch (_) {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> saveSetting(
    String key,
    bool value,
  ) async {
    await storage.write(
      key: key,
      value: value.toString(),
    );
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
        .showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> changeRememberLogin(
    bool value,
  ) async {
    setState(() {
      rememberLogin = value;
    });

    await saveSetting(
      rememberLoginKey,
      value,
    );

    if (value) {
      final user =
          Supabase.instance.client.auth.currentUser;

      if (user != null) {
        await storage.write(
          key: loginFlagKey,
          value: 'true',
        );
      }

      showMessage(
        'Keep me signed in is enabled.',
      );
    } else {
      await storage.delete(
        key: loginFlagKey,
      );

      showMessage(
        'Keep me signed in is disabled. '
        'You will need to log in again next time '
        'you open TomBrian.',
      );
    }
  }

  Future<void> changePassword() async {
    final passwordController =
        TextEditingController();

    final confirmController =
        TextEditingController();

    bool obscurePassword = true;
    bool obscureConfirm = true;
    bool changing = false;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            dialogBuildContext,
            setDialogState,
          ) {
            Future<void> updatePassword() async {
              final password =
                  passwordController.text;

              final confirm =
                  confirmController.text;

              if (password.length < 6) {
                ScaffoldMessenger.of(
                  dialogBuildContext,
                ).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Password must be at least 6 characters.',
                    ),
                  ),
                );
                return;
              }

              if (password != confirm) {
                ScaffoldMessenger.of(
                  dialogBuildContext,
                ).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Passwords do not match.',
                    ),
                  ),
                );
                return;
              }

              setDialogState(
                () => changing = true,
              );

              try {
                await Supabase
                    .instance
                    .client
                    .auth
                    .updateUser(
                  UserAttributes(
                    password: password,
                  ),
                );

                if (!dialogContext.mounted) {
                  return;
                }

                Navigator.pop(dialogContext);

                if (mounted) {
                  showMessage(
                    'Password changed successfully.',
                  );
                }
              } on AuthException catch (e) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(
                    dialogBuildContext,
                  ).showSnackBar(
                    SnackBar(
                      content: Text(e.message),
                    ),
                  );
                }
              } catch (e) {
                if (dialogContext.mounted) {
                  ScaffoldMessenger.of(
                    dialogBuildContext,
                  ).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Could not change password: $e',
                      ),
                    ),
                  );
                }
              } finally {
                if (dialogContext.mounted) {
                  setDialogState(
                    () => changing = false,
                  );
                }
              }
            }

            return AlertDialog(
              title: const Text(
                'Change password',
              ),
              content:
                  SingleChildScrollView(
                child: Column(
                  mainAxisSize:
                      MainAxisSize.min,
                  children: [
                    TextField(
                      controller:
                          passwordController,
                      obscureText:
                          obscurePassword,
                      enabled: !changing,
                      decoration:
                          InputDecoration(
                        labelText:
                            'New password',
                        prefixIcon:
                            const Icon(
                          Icons.lock_outline,
                        ),
                        suffixIcon:
                            IconButton(
                          onPressed: changing
                              ? null
                              : () =>
                                  setDialogState(
                                () =>
                                    obscurePassword =
                                        !obscurePassword,
                              ),
                          icon: Icon(
                            obscurePassword
                                ? Icons
                                    .visibility_off
                                : Icons.visibility,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      controller:
                          confirmController,
                      obscureText:
                          obscureConfirm,
                      enabled: !changing,
                      decoration:
                          InputDecoration(
                        labelText:
                            'Confirm new password',
                        prefixIcon:
                            const Icon(
                          Icons.lock_outline,
                        ),
                        suffixIcon:
                            IconButton(
                          onPressed: changing
                              ? null
                              : () =>
                                  setDialogState(
                                () =>
                                    obscureConfirm =
                                        !obscureConfirm,
                              ),
                          icon: Icon(
                            obscureConfirm
                                ? Icons
                                    .visibility_off
                                : Icons.visibility,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: changing
                      ? null
                      : () => Navigator.pop(
                            dialogContext,
                          ),
                  child: const Text(
                    'Cancel',
                  ),
                ),
                FilledButton(
                  onPressed: changing
                      ? null
                      : updatePassword,
                  child: changing
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Text(
                          'Update password',
                        ),
                ),
              ],
            );
          },
        );
      },
    );

    passwordController.dispose();
    confirmController.dispose();
  }

  Future<void> logout() async {
    final shouldLogout =
        await showDialog<bool>(
      context: context,
      builder: (dialogContext) =>
          AlertDialog(
        title: const Text(
          'Log out of TomBrian?',
        ),
        content: const Text(
          'Are you sure you want to log out?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(
              dialogContext,
              false,
            ),
            child: const Text(
              'Cancel',
            ),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(
              dialogContext,
              true,
            ),
            child: const Text(
              'Log Out',
            ),
          ),
        ],
      ),
    );

    if (shouldLogout != true) return;

    try {
      await Supabase.instance.client.auth
          .signOut();

      await _clearLoginFlag();

      if (!mounted) return;

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => const LoginPage(),
        ),
        (_) => false,
      );
    } on AuthException catch (e) {
      showMessage(
        'Could not log out: ${e.message}',
      );
    } catch (e) {
      showMessage(
        'Could not log out: $e',
      );
    }
  }

  Future<void> openExternal(Uri uri, String failureMessage) async {
    try {
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched && mounted) showMessage(failureMessage);
    } catch (_) {
      if (mounted) showMessage(failureMessage);
    }
  }

  Future<void> callNumber(String number) async {
    await openExternal(Uri.parse('tel:$number'), 'Could not open the phone dialer.');
  }

  Future<void> openWhatsApp() async {
    await openExternal(Uri.parse('https://wa.me/254746880971?text=${Uri.encodeComponent('Hello TomBrian Customer Care, I need assistance.')}'), 'Could not open WhatsApp.');
  }

  Future<void> sendEmail() async {
    await openExternal(Uri.parse('mailto:tombriankoech@gmail.com?subject=${Uri.encodeComponent('TomBrian Support Request')}'), 'Could not open your email app.');
  }

  void showCallOptions(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Call TomBrian', style: TextStyle(fontWeight: FontWeight.w800))),
            ListTile(leading: const Icon(Icons.phone), title: const Text('0746880971'), onTap: () { Navigator.pop(sheetContext); callNumber('0746880971'); }),
            ListTile(leading: const Icon(Icons.phone), title: const Text('0726510670'), onTap: () { Navigator.pop(sheetContext); callNumber('0726510670'); }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void showPrivacyPolicy(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text('TomBrian respects your privacy. Account information is used to provide the services you request, maintain account security and support transactions. We do not ask you to share passwords or payment-card credentials with Customer Care. Contact TomBrian if you have questions about your account information.'),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Close'))],
      ),
    );
  }

  void showLanguageDialog() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) =>
          AlertDialog(
        title: const Text(
          'Language',
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.check),
              title: Text('English'),
              subtitle: Text(
                'Current language',
              ),
            ),
            ListTile(
              leading: Icon(
                Icons.language_outlined,
              ),
              title: Text(
                'More languages',
              ),
              subtitle: Text(
                'Coming soon',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(
              dialogContext,
            ),
            child: const Text(
              'Close',
            ),
          ),
        ],
      ),
    );
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(
        left: 4,
        top: 22,
        bottom: 10,
      ),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          color: Color(0xFFD9A441),
          fontSize: 12,
          fontWeight: FontWeight.w800,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget settingsCard({
    required Widget child,
  }) {
    return Card(
      margin: EdgeInsets.zero,
      color: const Color(0xFF111624),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: const BorderSide(
          color: Color(0x221FFFFFF),
        ),
      ),
      child: child,
    );
  }

  Widget switchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      secondary: Icon(
        icon,
        color: const Color(0xFFD9A441),
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(
          color: Colors.white60,
          fontSize: 13,
        ),
      ),
      value: value,
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: loading
          ? const Center(
              child:
                  CircularProgressIndicator(),
            )
          : ListView(
              padding:
                  const EdgeInsets.fromLTRB(
                20,
                8,
                20,
                30,
              ),
              children: [
                const Text(
                  'Settings',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Manage your TomBrian account, security and preferences.',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 14,
                  ),
                ),

                sectionTitle(
                  'Account & Login',
                ),

                settingsCard(
                  child: Column(
                    children: [
                      switchTile(
                        icon: Icons.login,
                        title:
                            'Keep me signed in',
                        subtitle:
                            'Stay signed in on this device when you reopen TomBrian.',
                        value: rememberLogin,
                        onChanged:
                            changeRememberLogin,
                      ),
                      const Divider(
                        height: 1,
                      ),
                      ListTile(
                        leading: const Icon(
                          Icons.lock_reset,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'Change password',
                        ),
                        subtitle:
                            const Text(
                          'Update your TomBrian account password.',
                          style: TextStyle(
                            color:
                                Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        trailing:
                            const Icon(
                          Icons.chevron_right,
                        ),
                        onTap:
                            changePassword,
                      ),
                    ],
                  ),
                ),

                sectionTitle(
                  'Notifications',
                ),

                settingsCard(
                  child: Column(
                    children: [
                      switchTile(
                        icon: Icons
                            .receipt_long_outlined,
                        title:
                            'Transaction notifications',
                        subtitle:
                            'Get alerts about successful and failed transactions.',
                        value:
                            transactionNotifications,
                        onChanged: (value) async {
                          setState(
                            () =>
                                transactionNotifications =
                                    value,
                          );

                          await saveSetting(
                            transactionNotificationsKey,
                            value,
                          );
                        },
                      ),
                      const Divider(
                        height: 1,
                      ),
                      switchTile(
                        icon: Icons
                            .warning_amber_outlined,
                        title:
                            'Important account alerts',
                        subtitle:
                            'Receive important security and account notices.',
                        value:
                            accountAlerts,
                        onChanged: (value) async {
                          setState(
                            () =>
                                accountAlerts =
                                    value,
                          );

                          await saveSetting(
                            accountAlertsKey,
                            value,
                          );
                        },
                      ),
                      const Divider(
                        height: 1,
                      ),
                      switchTile(
                        icon: Icons
                            .local_offer_outlined,
                        title:
                            'Promotions & offers',
                        subtitle:
                            'Receive TomBrian offers and service updates.',
                        value: promotions,
                        onChanged: (value) async {
                          setState(
                            () => promotions =
                                value,
                          );

                          await saveSetting(
                            promotionsKey,
                            value,
                          );
                        },
                      ),
                    ],
                  ),
                ),

                sectionTitle(
                  'App Preferences',
                ),

                settingsCard(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(
                          Icons.dark_mode_outlined,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'Appearance',
                        ),
                        subtitle:
                            const Text(
                          'TomBrian is currently using dark mode.',
                          style: TextStyle(
                            color:
                                Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        trailing:
                            const Text(
                          'Dark',
                          style: TextStyle(
                            color:
                                Color(0xFFD9A441),
                            fontWeight:
                                FontWeight.w700,
                          ),
                        ),
                        onTap: () => showMessage('TomBrian is currently using dark mode.'),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      ListTile(
                        leading: const Icon(
                          Icons.language_outlined,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'Language',
                        ),
                        subtitle:
                            const Text(
                          'Choose your preferred app language.',
                          style: TextStyle(
                            color:
                                Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        trailing:
                            const Text(
                          'English',
                          style: TextStyle(
                            color:
                                Color(0xFFD9A441),
                            fontWeight:
                                FontWeight.w700,
                          ),
                        ),
                        onTap:
                            showLanguageDialog,
                      ),
                    ],
                  ),
                ),

                sectionTitle(
                  'Support & Information',
                ),

                settingsCard(
                  child: Column(
                    children: [
                      ListTile(
                        leading: const Icon(
                          Icons.support_agent,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'TomBrian Support Center',
                        ),
                        subtitle:
                            const Text(
                          'Get help with your account and transactions.',
                          style: TextStyle(
                            color:
                                Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        trailing:
                            const Icon(
                          Icons.chevron_right,
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const SupportPage()),
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      ListTile(
                        leading: const Icon(
                          Icons
                              .description_outlined,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'Terms & Conditions',
                        ),
                        trailing:
                            const Icon(
                          Icons.chevron_right,
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const TermsAndConditionsPage()),
                        ),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      ListTile(
                        leading: const Icon(
                          Icons
                              .privacy_tip_outlined,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'Privacy Policy',
                        ),
                        trailing:
                            const Icon(
                          Icons.chevron_right,
                        ),
                        onTap: () => showPrivacyPolicy(context),
                      ),
                      const Divider(
                        height: 1,
                      ),
                      ListTile(
                        leading: const Icon(
                          Icons.info_outline,
                          color:
                              Color(0xFFD9A441),
                        ),
                        title: const Text(
                          'About TomBrian',
                        ),
                        subtitle:
                            const Text(
                          'Version 1.0.0',
                          style: TextStyle(
                            color:
                                Colors.white60,
                            fontSize: 13,
                          ),
                        ),
                        trailing:
                            const Icon(
                          Icons.chevron_right,
                        ),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const AboutTomBrianPage()),
                        ),
                      ),
                    ],
                  ),
                ),

                sectionTitle(
                  'Contact Us',
                ),

                settingsCard(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      vertical: 8,
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(
                            Icons.phone_outlined,
                            color: Color(0xFFD9A441),
                          ),
                          title: const Text(
                            'Call Us',
                          ),
                          subtitle: const Text(
                            '0746880971 / 0726510670',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                          onTap: () => showCallOptions(context),
                        ),
                        const Divider(
                          height: 1,
                        ),
                        ListTile(
                          leading: const Icon(
                            Icons.chat_outlined,
                            color: Color(0xFFD9A441),
                          ),
                          title: const Text(
                            'WhatsApp',
                          ),
                          subtitle: const Text(
                            '0746880971',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                          onTap: openWhatsApp,
                        ),
                        const Divider(
                          height: 1,
                        ),
                        ListTile(
                          leading: const Icon(
                            Icons.email_outlined,
                            color: Color(0xFFD9A441),
                          ),
                          title: const Text(
                            'Email',
                          ),
                          subtitle: const Text(
                            'tombriankoech@gmail.com',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                          onTap: sendEmail,
                        ),
                        const Divider(
                          height: 1,
                        ),
                        ListTile(
                          leading: const Icon(
                            Icons.access_time_outlined,
                            color: Color(0xFFD9A441),
                          ),
                          title: const Text(
                            'Business Hours',
                          ),
                          subtitle: const Text(
                            '7:00 AM – 9:00 PM',
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                sectionTitle(
                  'Account',
                ),

                SizedBox(
                  height: 54,
                  child: FilledButton.icon(
                    onPressed: logout,
                    icon: const Icon(
                      Icons.logout,
                    ),
                    label: const Text(
                      'Log Out',
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                const Center(
                  child: Text(
                    'TomBrian • Dream • Work • Achieve',
                    style: TextStyle(
                      color: Colors.white38,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() =>
      _ProfilePageState();
}

class _ProfilePageState
    extends State<ProfilePage> {
  final fullNameController =
      TextEditingController();

  final phoneController =
      TextEditingController();

  final businessNameController =
      TextEditingController();

  final businessTypeController =
      TextEditingController();

  final businessLocationController =
      TextEditingController();

  bool loading = true;
  bool saving = false;

  @override
  void initState() {
    super.initState();
    loadProfile();
  }

  Future<void> loadProfile() async {
    try {
      final user =
          Supabase.instance.client.auth.currentUser;

      if (user == null) {
        if (mounted) {
          setState(
            () => loading = false,
          );
        }
        return;
      }

      final profile =
          await Supabase.instance.client
              .from('profiles')
              .select(
                'full_name, phone, business_name, business_type, business_location',
              )
              .eq('id', user.id)
              .maybeSingle();

      if (profile != null) {
        fullNameController.text =
            (profile['full_name'] ?? '')
                .toString();

        phoneController.text =
            (profile['phone'] ?? '')
                .toString();

        businessNameController.text =
            (profile['business_name'] ?? '')
                .toString();

        businessTypeController.text =
            (profile['business_type'] ?? '')
                .toString();

        businessLocationController.text =
            (profile['business_location'] ?? '')
                .toString();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Could not load profile: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(
          () => loading = false,
        );
      }
    }
  }

  Future<void> saveProfile() async {
    final user =
        Supabase.instance.client.auth.currentUser;

    if (user == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please log in first.',
          ),
        ),
      );
      return;
    }

    if (fullNameController.text
        .trim()
        .isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter your full name.',
          ),
        ),
      );
      return;
    }

    if (saving) return;

    setState(() => saving = true);

    try {
      await Supabase.instance.client
          .from('profiles')
          .upsert(
        {
          'id': user.id,
          'full_name':
              fullNameController.text.trim(),
          'phone':
              phoneController.text.trim(),
          'business_name':
              businessNameController.text.trim(),
          'business_type':
              businessTypeController.text.trim(),
          'business_location':
              businessLocationController.text.trim(),
          'updated_at':
              DateTime.now()
                  .toIso8601String(),
        },
        onConflict: 'id',
      );

      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              'Profile saved successfully.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Could not save profile: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(
          () => saving = false,
        );
      }
    }
  }

  @override
  void dispose() {
    fullNameController.dispose();
    phoneController.dispose();
    businessNameController.dispose();
    businessTypeController.dispose();
    businessLocationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final loggedIn =
        Supabase.instance.client.auth.currentUser !=
            null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
      ),
      body: loading
          ? const Center(
              child:
                  CircularProgressIndicator(),
            )
          : !loggedIn
              ? Center(
                  child: Padding(
                    padding:
                        const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment:
                          MainAxisAlignment.center,
                      children: [
                        const Icon(
                          Icons.lock_outline,
                          size: 70,
                          color:
                              Color(0xFFD9A441),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          'Login required',
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        const Text(
                          'Please log in to create or view your profile.',
                          textAlign:
                              TextAlign.center,
                          style: TextStyle(
                            color:
                                Colors.white60,
                          ),
                        ),
                        const SizedBox(
                          height: 24,
                        ),
                        SizedBox(
                          width:
                              double.infinity,
                          height: 54,
                          child:
                              FilledButton.icon(
                            onPressed: () =>
                                Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    const LoginPage(),
                              ),
                            ),
                            icon: const Icon(
                              Icons.login,
                            ),
                            label: const Text(
                              'Log In',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                )
              : SingleChildScrollView(
                  padding:
                      const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      const CircleAvatar(
                        radius: 45,
                        child: Icon(
                          Icons.person,
                          size: 50,
                        ),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      TextField(
                        controller:
                            fullNameController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Full name',
                          prefixIcon:
                              Icon(
                            Icons
                                .person_outline,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextField(
                        controller:
                            phoneController,
                        keyboardType:
                            TextInputType.phone,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Phone number',
                          prefixIcon:
                              Icon(
                            Icons
                                .phone_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextField(
                        controller:
                            businessNameController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Business name',
                          prefixIcon:
                              Icon(
                            Icons
                                .business_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextField(
                        controller:
                            businessTypeController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Business type',
                          prefixIcon:
                              Icon(
                            Icons
                                .category_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextField(
                        controller:
                            businessLocationController,
                        decoration:
                            const InputDecoration(
                          labelText:
                              'Business location',
                          prefixIcon:
                              Icon(
                            Icons
                                .location_on_outlined,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 24,
                      ),
                      SizedBox(
                        width:
                            double.infinity,
                        height: 54,
                        child:
                            FilledButton.icon(
                          onPressed: saving
                              ? null
                              : saveProfile,
                          icon: saving
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child:
                                      CircularProgressIndicator(
                                    strokeWidth:
                                        2,
                                  ),
                                )
                              : const Icon(
                                  Icons.save,
                                ),
                          label: Text(
                            saving
                                ? 'Saving...'
                                : 'Save Profile',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() =>
      _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  static const storage = FlutterSecureStorage();

  static const loginFlagKey =
      'tombrian_logged_in';

  static const rememberLoginKey =
      'tombrian_customer_remember';

  final emailController =
      TextEditingController();

  final passwordController =
      TextEditingController();

  bool loading = false;
  bool showPassword = false;
  bool rememberLogin = true;

  @override
  void initState() {
    super.initState();
    loadRememberLogin();
  }

  Future<void> loadRememberLogin() async {
    try {
      final saved = await storage.read(
        key: rememberLoginKey,
      );

      if (!mounted) return;

      setState(() {
        rememberLogin = saved != 'false';
      });
    } catch (_) {}
  }

  Future<void> resetPassword() async {
    final email =
        emailController.text.trim();

    if (email.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Enter your email address first.',
          ),
        ),
      );
      return;
    }

    try {
      await Supabase.instance.client.auth
          .resetPasswordForEmail(email);

      if (!mounted) return;

      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Password reset email sent. Please check your email.',
          ),
          duration:
              Duration(seconds: 5),
        ),
      );
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(e.message),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Could not send reset email: $e',
            ),
          ),
        );
      }
    }
  }

  Future<void> login() async {
    final email =
        emailController.text.trim();

    final password =
        passwordController.text;

    if (email.isEmpty ||
        password.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter your email and password.',
          ),
        ),
      );
      return;
    }

    if (loading) return;

    setState(() => loading = true);

    try {
      final response =
          await Supabase.instance.client.auth
              .signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;

      if (user == null) {
        throw const AuthException(
          'Login failed. Please try again.',
        );
      }

      await ReferralService.claimPendingReferral();

      final profile =
          await Supabase.instance.client
              .from('profiles')
              .select('role, agent_approved')
              .eq('id', user.id)
              .maybeSingle();

      final role =
          profile?['role']?.toString().toLowerCase();
      final agentApproved = profile?['agent_approved'] == true;

      // Always save the current preference.
      await storage.write(
        key: rememberLoginKey,
        value: rememberLogin.toString(),
      );

      if (rememberLogin) {
        // This flag tells LoginGate that the user
        // deliberately logged in and chose persistence.
        await storage.write(
          key: loginFlagKey,
          value: 'true',
        );
      } else {
        // Do not keep the login flag when the
        // customer chose not to stay signed in.
        await storage.delete(
          key: loginFlagKey,
        );
      }

      if (!mounted) return;

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) =>
              role == 'admin'
                  ? const AdminDashboardPage()
                  : role == 'agent' && agentApproved
                      ? const AgentDashboardPage()
                      : const HomePage(),
        ),
        (_) => false,
      );
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(e.message),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Login failed: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(
          () => loading = false,
        );
      }
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'TomBrian Login',
        ),
      ),
      body: SingleChildScrollView(
        padding:
            const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(
              height: 40,
            ),
            const Icon(
              Icons.person_outline,
              size: 80,
              color: Color(0xFFD9A441),
            ),
            const SizedBox(
              height: 24,
            ),
            const Text(
              'Welcome to TomBrian',
              style: TextStyle(
                fontSize: 28,
                fontWeight:
                    FontWeight.bold,
              ),
              textAlign:
                  TextAlign.center,
            ),
            const SizedBox(
              height: 8,
            ),
            const Text(
              'Log in to continue.',
              style: TextStyle(
                color: Colors.white60,
                fontSize: 16,
              ),
            ),
            const SizedBox(
              height: 30,
            ),
            TextField(
              controller:
                  emailController,
              keyboardType:
                  TextInputType.emailAddress,
              decoration:
                  const InputDecoration(
                prefixIcon: Icon(
                  Icons.email_outlined,
                ),
                labelText: 'Email',
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            TextField(
              controller:
                  passwordController,
              obscureText:
                  !showPassword,
              decoration:
                  InputDecoration(
                prefixIcon:
                    const Icon(
                  Icons.lock_outline,
                ),
                labelText: 'Password',
                suffixIcon:
                    IconButton(
                  icon: Icon(
                    showPassword
                        ? Icons.visibility
                        : Icons.visibility_off,
                  ),
                  onPressed: () =>
                      setState(
                    () => showPassword =
                        !showPassword,
                  ),
                ),
              ),
            ),

            const SizedBox(
              height: 8,
            ),

            CheckboxListTile(
              contentPadding:
                  EdgeInsets.zero,
              value: rememberLogin,
              onChanged: loading
                  ? null
                  : (value) async {
                      final newValue =
                          value ?? false;

                      setState(() {
                        rememberLogin =
                            newValue;
                      });

                      await storage.write(
                        key:
                            rememberLoginKey,
                        value:
                            newValue.toString(),
                      );
                    },
              title: const Text(
                'Keep me signed in',
              ),
              subtitle: const Text(
                'Stay signed in on this device.',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 13,
                ),
              ),
              controlAffinity:
                  ListTileControlAffinity
                      .leading,
            ),

            const SizedBox(
              height: 12,
            ),

            SizedBox(
              width:
                  double.infinity,
              height: 54,
              child: FilledButton(
                onPressed:
                    loading ? null : login,
                child: loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child:
                            CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                    : const Text(
                        'Log In',
                      ),
              ),
            ),

            TextButton(
              onPressed:
                  loading ? null : resetPassword,
              child: const Text(
                'Forgot password?',
              ),
            ),

            const SizedBox(
              height: 12,
            ),

            TextButton(
              onPressed: () =>
                  Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const SignUpPage(),
                ),
              ),
              child: const Text(
                'Sign Up',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() =>
      _SignUpPageState();
}

class _SignUpPageState
    extends State<SignUpPage> {
  final fullNameController =
      TextEditingController();

  final phoneController =
      TextEditingController();

  final emailController =
      TextEditingController();

  final passwordController =
      TextEditingController();

  final confirmPasswordController =
      TextEditingController();

  final referralCodeController =
      TextEditingController();

  bool loading = false;
  bool showPassword = false;
  bool showConfirmPassword = false;

  @override
  void initState() {
    super.initState();
    loadPendingReferral();
  }

  Future<void> loadPendingReferral() async {
    try {
      final code = await ReferralService.getPendingReferral();
      if (!mounted || code == null || code.isEmpty) return;
      setState(() => referralCodeController.text = code);
    } catch (_) {}
  }

  Future<void> signUp() async {
    final fullName =
        fullNameController.text.trim();

    final phone =
        phoneController.text.trim();

    final email =
        emailController.text.trim();

    final password =
        passwordController.text;

    final confirm =
        confirmPasswordController.text;

    final referralCode =
        referralCodeController.text.trim().toUpperCase();

    if (fullName.isEmpty ||
        phone.isEmpty ||
        email.isEmpty ||
        password.isEmpty ||
        confirm.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please fill in all fields.',
          ),
        ),
      );
      return;
    }

    if (!RegExp(
      r'^(07|01)\d{8}$',
    ).hasMatch(phone)) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid Kenyan phone number.',
          ),
        ),
      );
      return;
    }

    if (!RegExp(
      r'^[^@\s]+@[^@\s]+\.[^@\s]+$',
    ).hasMatch(email)) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Please enter a valid email address.',
          ),
        ),
      );
      return;
    }

    if (password.length < 6) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Password must be at least 6 characters.',
          ),
        ),
      );
      return;
    }

    if (password != confirm) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Passwords do not match.',
          ),
        ),
      );
      return;
    }

    if (loading) return;

    setState(() => loading = true);

    try {
      final response =
          await Supabase.instance.client.auth
              .signUp(
        email: email,
        password: password,
        emailRedirectTo:
            tombrianRedirectUrl,
        data: {
          'full_name': fullName,
          'phone': phone,
          if (referralCode.isNotEmpty) 'referral_code': referralCode,
        },
      ).timeout(
        const Duration(
          seconds: 30,
        ),
      );

      if (!mounted) return;

      final newUser = response.user;

      if (newUser == null) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              'Account was not created. Please try again.',
            ),
          ),
        );
        return;
      }

      final confirmation =
          response.session == null;

      if (referralCode.isNotEmpty) {
        await ReferralService.savePendingReferral(referralCode);
      }

      if (response.session != null) {
        // Create the new customer's own invite code immediately.
        // This is independent of whether they were referred by someone else.
        try {
          await ReferralService.ensureReferralCode();
        } catch (_) {}

        if (referralCode.isNotEmpty) {
          await ReferralService.claimPendingReferral();
        }
      }

      ScaffoldMessenger.of(context)
          .showSnackBar(
        SnackBar(
          content: Text(
            confirmation
                ? 'Account created. Please check your email to confirm your account.'
                : 'Account created successfully. You can now log in.',
          ),
          duration:
              const Duration(seconds: 4),
        ),
      );

      await Future<void>.delayed(
        const Duration(
          milliseconds: 800,
        ),
      );

      if (mounted && response.session != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => const ReferralPage(),
          ),
        );
      } else if (mounted) {
        Navigator.pop(context);
      }
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(e.message),
            duration:
                const Duration(seconds: 5),
          ),
        );
      }
    } on TimeoutException {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          const SnackBar(
            content: Text(
              'The request took too long. Check your internet connection and try again.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Sign up failed: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(
          () => loading = false,
        );
      }
    }
  }

  @override
  void dispose() {
    fullNameController.dispose();
    phoneController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    referralCodeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Create Account',
        ),
      ),
      body: SingleChildScrollView(
        padding:
            const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Icon(
              Icons.person_add_outlined,
              size: 65,
              color: Color(0xFFD9A441),
            ),
            const SizedBox(
              height: 20,
            ),
            const Text(
              'Create Account',
              style: TextStyle(
                fontSize: 28,
                fontWeight:
                    FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 8,
            ),
            const Text(
              'Enter your details to create your TomBrian account.',
              style: TextStyle(
                color: Colors.white60,
              ),
            ),
            const SizedBox(
              height: 24,
            ),
            TextField(
              controller:
                  fullNameController,
              textCapitalization:
                  TextCapitalization.words,
              decoration:
                  const InputDecoration(
                prefixIcon: Icon(
                  Icons.person_outline,
                ),
                labelText:
                    'Full name',
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            TextField(
              controller:
                  phoneController,
              keyboardType:
                  TextInputType.phone,
              decoration:
                  const InputDecoration(
                prefixIcon: Icon(
                  Icons.phone_outlined,
                ),
                labelText:
                    'Phone number',
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            TextField(
              controller:
                  emailController,
              keyboardType:
                  TextInputType.emailAddress,
              decoration:
                  const InputDecoration(
                prefixIcon: Icon(
                  Icons.email_outlined,
                ),
                labelText: 'Email',
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            TextField(
              controller: referralCodeController,
              textCapitalization: TextCapitalization.characters,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.card_giftcard_outlined),
                labelText: 'Referral code (optional)',
                hintText: 'TBXXXXXXXX',
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            PasswordField(
              controller:
                  passwordController,
              label: 'Password',
              visible:
                  showPassword,
              onToggle: () =>
                  setState(
                () => showPassword =
                    !showPassword,
              ),
            ),
            const SizedBox(
              height: 14,
            ),
            PasswordField(
              controller:
                  confirmPasswordController,
              label:
                  'Confirm password',
              visible:
                  showConfirmPassword,
              onToggle: () =>
                  setState(
                () =>
                    showConfirmPassword =
                        !showConfirmPassword,
              ),
            ),
            const SizedBox(
              height: 24,
            ),
            SizedBox(
              width:
                  double.infinity,
              height: 54,
              child: FilledButton(
                onPressed:
                    loading ? null : signUp,
                child: loading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child:
                            CircularProgressIndicator(
                          strokeWidth: 2,
                        ),
                      )
                    : const Text(
                        'Create Account',
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PasswordField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool visible;
  final VoidCallback onToggle;

  const PasswordField({
    super.key,
    required this.controller,
    required this.label,
    required this.visible,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: !visible,
      decoration:
          InputDecoration(
        prefixIcon:
            const Icon(
          Icons.lock_outline,
        ),
        labelText: label,
        suffixIcon:
            IconButton(
          icon: Icon(
            visible
                ? Icons.visibility
                : Icons.visibility_off,
          ),
          onPressed: onToggle,
        ),
      ),
    );
  }
}

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() =>
      _AdminLoginPageState();
}

class _AdminLoginPageState
    extends State<AdminLoginPage> {
  static const storage =
      FlutterSecureStorage();

  static const emailKey =
      'tombrian_admin_email';

  static const passwordKey =
      'tombrian_admin_password';

  static const rememberKey =
      'tombrian_admin_remember';

  static const loginFlagKey =
      'tombrian_logged_in';

  final emailController =
      TextEditingController();

  final passwordController =
      TextEditingController();

  bool loading = false;
  bool showPassword = false;
  bool rememberMe = true;

  @override
  void initState() {
    super.initState();
    loadRemembered();
  }

  Future<void> loadRemembered() async {
    try {
      final remembered =
          await storage.read(
        key: rememberKey,
      );

      final email =
          await storage.read(
        key: emailKey,
      );

      final password =
          await storage.read(
        key: passwordKey,
      );

      if (!mounted) return;

      setState(() {
        rememberMe =
            remembered != 'false';

        if (rememberMe) {
          emailController.text =
              email ?? '';

          passwordController.text =
              password ?? '';
        }
      });
    } catch (_) {}
  }

  Future<void> saveRemembered() async {
    if (rememberMe) {
      await storage.write(
        key: emailKey,
        value:
            emailController.text.trim(),
      );

      await storage.write(
        key: passwordKey,
        value:
            passwordController.text,
      );

      await storage.write(
        key: rememberKey,
        value: 'true',
      );
    } else {
      await storage.delete(
        key: emailKey,
      );

      await storage.delete(
        key: passwordKey,
      );

      await storage.write(
        key: rememberKey,
        value: 'false',
      );
    }
  }

  Future<void> login() async {
    final email =
        emailController.text.trim();

    final password =
        passwordController.text;

    if (email.isEmpty ||
        password.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(
        const SnackBar(
          content: Text(
            'Enter your admin email and password.',
          ),
        ),
      );
      return;
    }

    if (loading) return;

    setState(() => loading = true);

    try {
      final response =
          await Supabase.instance.client.auth
              .signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;

      if (user == null) {
        await Supabase.instance.client
            .auth
            .signOut();

        throw const AuthException(
          'Admin login failed.',
        );
      }

      final profile =
          await Supabase.instance.client
              .from('profiles')
              .select('role')
              .eq('id', user.id)
              .maybeSingle();

      final role =
          profile?['role']?.toString().toLowerCase();

      if (role != 'admin') {
        await Supabase.instance.client
            .auth
            .signOut();

        throw const AuthException(
          'This account is not an admin account.',
        );
      }

      await saveRemembered();

      await storage.write(
        key: loginFlagKey,
        value: 'true',
      );

      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) =>
                const AdminDashboardPage(),
          ),
        );
      }
    } on AuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(e.message),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(
          SnackBar(
            content: Text(
              'Admin login failed: $e',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(
          () => loading = false,
        );
      }
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Admin Login',
        ),
      ),
      body: ListView(
        padding:
            const EdgeInsets.all(20),
        children: [
          const Icon(
            Icons
                .admin_panel_settings_outlined,
            size: 80,
          ),
          const SizedBox(
            height: 20,
          ),
          const Text(
            'TomBrian Admin',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 28,
              fontWeight:
                  FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          const Text(
            'Sign in to access users, balances and transactions.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              color: Colors.white60,
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          TextField(
            controller:
                emailController,
            keyboardType:
                TextInputType.emailAddress,
            decoration:
                const InputDecoration(
              prefixIcon:
                  Icon(
                Icons.email_outlined,
              ),
              labelText:
                  'Admin email',
            ),
          ),
          const SizedBox(
            height: 14,
          ),
          PasswordField(
            controller:
                passwordController,
            label: 'Password',
            visible:
                showPassword,
            onToggle: () =>
                setState(
              () => showPassword =
                  !showPassword,
            ),
          ),
          const SizedBox(
            height: 8,
          ),
          CheckboxListTile(
            contentPadding:
                EdgeInsets.zero,
            value: rememberMe,
            onChanged: (v) =>
                setState(
              () => rememberMe =
                  v ?? false,
            ),
            title: const Text(
              'Remember me',
            ),
            controlAffinity:
                ListTileControlAffinity
                    .leading,
          ),
          const SizedBox(
            height: 12,
          ),
          SizedBox(
            height: 54,
            child: FilledButton(
              onPressed:
                  loading ? null : login,
              child: loading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child:
                          CircularProgressIndicator(
                        strokeWidth: 2,
                      ),
                    )
                  : const Text(
                      'Admin Login',
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class AdminDashboardPage extends StatefulWidget {
  const AdminDashboardPage({super.key});

  @override
  State<AdminDashboardPage> createState() => _AdminDashboardPageState();
}

class _AdminDashboardPageState extends State<AdminDashboardPage> {
  static const storage = FlutterSecureStorage();
  static const loginFlagKey = 'tombrian_logged_in';

  bool loading = true;
  String? error;

  List<Map<String, dynamic>> profiles = [];
  List<Map<String, dynamic>> balances = [];
  List<Map<String, dynamic>> transactions = [];
  List<Map<String, dynamic>> agentApplications = [];

  @override
  void initState() {
    super.initState();
    loadAdminData();
  }

  Future<void> loadAdminData() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }

    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) throw Exception('Admin authentication required.');

      final profile = await client.from('profiles').select('role').eq('id', user.id).maybeSingle();
      if (profile?['role']?.toString().toLowerCase() != 'admin') {
        throw Exception('Admin authentication required.');
      }

      final profileData = await client.from('profiles').select(
        'id, full_name, phone, business_name, business_type, business_location, role, created_at, updated_at',
      );
      final balanceData = await client.from('balances').select('user_id, balance, created_at, updated_at');
      final transactionData = await client.from('transactions').select(
        'id, user_id, amount, transaction_type, created_at',
      ).order('created_at', ascending: false);
      final applicationData = await client.from('agent_applications').select(
        'id, user_id, full_name, phone, reason, terms_agreed, status, admin_notes, created_at, updated_at',
      ).order('created_at', ascending: false);

      if (!mounted) return;
      setState(() {
        profiles = List<Map<String, dynamic>>.from(profileData);
        balances = List<Map<String, dynamic>>.from(balanceData);
        transactions = List<Map<String, dynamic>>.from(transactionData);
        agentApplications = List<Map<String, dynamic>>.from(applicationData);
        loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { loading = false; error = e.toString(); });
    }
  }

  String balanceFor(String userId) {
    for (final b in balances) {
      if (b['user_id']?.toString() == userId) return (b['balance'] ?? 0).toString();
    }
    return '0.00';
  }

  int get pendingApplications => agentApplications.where((a) => a['status']?.toString().toLowerCase() == 'pending').length;
  int get approvedApplications => agentApplications.where((a) => a['status']?.toString().toLowerCase() == 'approved').length;
  int get rejectedApplications => agentApplications.where((a) => a['status']?.toString().toLowerCase() == 'rejected').length;

  String formatDate(dynamic value) {
    if (value == null) return 'Unknown date';
    final parsed = DateTime.tryParse(value.toString());
    if (parsed == null) return value.toString();
    final d = parsed.toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${two(d.month)}-${two(d.day)} ${two(d.hour)}:${two(d.minute)}';
  }

  Future<void> updateApplicationStatus(Map<String, dynamic> application, String status, {String? notes}) async {
    final id = application['id']?.toString();
    if (id == null || id.isEmpty) return;
    try {
      final data = <String, dynamic>{'status': status, 'updated_at': DateTime.now().toIso8601String()};
      if (notes != null) data['admin_notes'] = notes.trim();
      final client = Supabase.instance.client;

      // Approval activates the user's agent role at the same time.
      if (status == 'approved') {
        final userId = application['user_id']?.toString();
        if (userId == null || userId.isEmpty) {
          throw Exception('This application has no user ID.');
        }

        await client
            .from('profiles')
            .update({
              'role': 'agent',
              'agent_approved': true,
              'updated_at': DateTime.now().toIso8601String(),
            })
            .eq('id', userId);
      }

      await client.from('agent_applications').update(data).eq('id', id);
      if (!mounted) return;
      await loadAdminData();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(status == 'approved' ? 'Agent application approved successfully.' : 'Agent application rejected.'),
        behavior: SnackBarBehavior.floating,
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Could not update application: $e')));
    }
  }

  Future<void> approveApplication(Map<String, dynamic> application) async {
    final name = (application['full_name'] ?? 'this applicant').toString();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Approve application?'),
        content: Text('Approve $name as an agent applicant?\n\nThe application status will be changed to Approved.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton.icon(onPressed: () => Navigator.pop(c, true), icon: const Icon(Icons.check), label: const Text('Approve')),
        ],
      ),
    );
    if (confirmed == true) await updateApplicationStatus(application, 'approved');
  }

  Future<void> rejectApplication(Map<String, dynamic> application) async {
    final notesController = TextEditingController();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Reject application'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Add a reason or note for the applicant. This will be visible on their Agent Application page.'),
          const SizedBox(height: 14),
          TextField(controller: notesController, maxLines: 4, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(labelText: 'Rejection reason / admin notes', hintText: 'Example: Please provide clearer business details.', alignLabelWithHint: true)),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton.icon(onPressed: () => Navigator.pop(c, true), icon: const Icon(Icons.close), label: const Text('Reject')),
        ],
      ),
    );
    if (confirmed == true) {
      await updateApplicationStatus(application, 'rejected', notes: notesController.text.trim().isEmpty ? 'Application was not approved at this time.' : notesController.text.trim());
    }
    notesController.dispose();
  }

  void showApplicationDetails(Map<String, dynamic> application) {
    final status = application['status']?.toString().toLowerCase() ?? 'pending';
    final name = (application['full_name'] ?? 'Unnamed applicant').toString();
    final phone = (application['phone'] ?? 'No phone').toString();
    final reason = (application['reason'] ?? 'No reason provided').toString();
    final notes = (application['admin_notes'] ?? '').toString().trim();
    final terms = application['terms_agreed'] == true;

    showDialog<void>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Row(children: [Icon(Icons.assignment_ind_outlined, color: Color(0xFFD9A441)), SizedBox(width: 10), Expanded(child: Text('Agent Application'))]),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          _applicationDetail('Applicant', name),
          _applicationDetail('Phone', phone),
          _applicationDetail('Status', status.toUpperCase()),
          _applicationDetail('Submitted', formatDate(application['created_at'])),
          _applicationDetail('Terms agreed', terms ? 'Yes' : 'No'),
          const SizedBox(height: 8),
          const Text('Reason for applying', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(12)), child: Text(reason)),
          if (notes.isNotEmpty) ...[
            const SizedBox(height: 14), const Text('Admin notes', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 6),
            Container(width: double.infinity, padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(12)), child: Text(notes)),
          ],
        ])),
        actions: [
          if (status == 'pending') ...[
            TextButton.icon(onPressed: () { Navigator.pop(c); rejectApplication(application); }, icon: const Icon(Icons.close), label: const Text('Reject')),
            FilledButton.icon(onPressed: () { Navigator.pop(c); approveApplication(application); }, icon: const Icon(Icons.check), label: const Text('Approve')),
          ] else TextButton(onPressed: () => Navigator.pop(c), child: const Text('Close')),
        ],
      ),
    );
  }

  Widget _applicationDetail(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [SizedBox(width: 105, child: Text(label, style: const TextStyle(color: Colors.white60))), Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w600)))]),
  );

  Widget applicationStatusChip(String status) {
    final n = status.toLowerCase();
    final icon = n == 'approved' ? Icons.check_circle_outline : n == 'rejected' ? Icons.cancel_outlined : Icons.hourglass_empty;
    return Chip(avatar: Icon(icon, size: 17), label: Text(n.isEmpty ? 'PENDING' : n.toUpperCase()));
  }

  Widget buildAgentApplicationsSection() {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Expanded(child: Text('Agent Applications', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))), if (pendingApplications > 0) Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFD9A441).withOpacity(0.15), borderRadius: BorderRadius.circular(20)), child: Text('$pendingApplications pending', style: const TextStyle(color: Color(0xFFD9A441), fontWeight: FontWeight.w800, fontSize: 12)))]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: AdminCard(title: 'Pending', value: '$pendingApplications', icon: Icons.hourglass_empty)), const SizedBox(width: 8),
        Expanded(child: AdminCard(title: 'Approved', value: '$approvedApplications', icon: Icons.check_circle_outline)), const SizedBox(width: 8),
        Expanded(child: AdminCard(title: 'Rejected', value: '$rejectedApplications', icon: Icons.cancel_outlined)),
      ]),
      const SizedBox(height: 12),
      if (agentApplications.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('No agent applications yet.')))
      else ...agentApplications.map((a) {
        final status = a['status']?.toString().toLowerCase() ?? 'pending';
        final name = (a['full_name'] ?? 'Unnamed applicant').toString();
        final phone = (a['phone'] ?? 'No phone').toString();
        final reason = (a['reason'] ?? 'No reason provided').toString();
        return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
          contentPadding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
          leading: CircleAvatar(backgroundColor: const Color(0xFFD9A441).withOpacity(0.15), child: const Icon(Icons.person_search_outlined, color: Color(0xFFD9A441))),
          title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const SizedBox(height: 4), Text(phone), const SizedBox(height: 6), Text(reason, maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 8), applicationStatusChip(status)]),
          onTap: () => showApplicationDetails(a),
        ));
      }),
    ]);
  }

  Future<void> logout() async {
    await Supabase.instance.client.auth.signOut();
    await storage.delete(key: loginFlagKey);
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AdminLoginPage()), (_) => false);
  }

  @override
  Widget build(BuildContext context) {
    Widget content;

    if (loading) {
      content = const Center(
        child: CircularProgressIndicator(),
      );
    } else if (error != null) {
      content = Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 50),
              const SizedBox(height: 12),
              Text(
                error!,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: loadAdminData,
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    } else {
      content = RefreshIndicator(
        onRefresh: loadAdminData,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'TomBrian Admin',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              'Manage users, balances, transactions and agent applications.',
              style: TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: AdminCard(
                    title: 'Users',
                    value: '${profiles.length}',
                    icon: Icons.people_outline,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: AdminCard(
                    title: 'Balances',
                    value: '${balances.length}',
                    icon: Icons.account_balance_wallet_outlined,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: AdminCard(
                    title: 'Transactions',
                    value: '${transactions.length}',
                    icon: Icons.receipt_long_outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            buildAgentApplicationsSection(),
            const SizedBox(height: 28),
            const Text(
              'All Users',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            if (profiles.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('No profile records yet.'),
                ),
              )
            else
              ...profiles.map((profile) {
                final id = profile['id']?.toString() ?? '';
                final name =
                    (profile['full_name'] ?? 'Unnamed user').toString();
                final phone =
                    (profile['phone'] ?? 'No phone').toString();
                final business =
                    (profile['business_name'] ?? '').toString();

                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.person),
                    ),
                    title: Text(name),
                    subtitle: Text(
                      business.isEmpty ? phone : '$phone\n$business',
                    ),
                    isThreeLine: business.isNotEmpty,
                    trailing: Text(
                      'KES ${balanceFor(id)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              }),
            const SizedBox(height: 24),
            const Text(
              'Recent Transactions',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            if (transactions.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('No transactions yet.'),
                ),
              )
            else
              ...transactions.take(20).map(
                    (tx) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.receipt_long),
                        title: Text(
                          '${tx['transaction_type'] ?? 'Transaction'} — '
                          'KES ${tx['amount'] ?? 0}',
                        ),
                        subtitle: Text(
                          'User: ${tx['user_id'] ?? ''}\n'
                          '${formatDate(tx['created_at'])}',
                        ),
                      ),
                    ),
                  ),
            const SizedBox(height: 30),
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
            onPressed: loadAdminData,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: content,
    );
  }
}


class AgentDashboardPage extends StatefulWidget {
  const AgentDashboardPage({super.key});

  @override
  State<AgentDashboardPage> createState() => _AgentDashboardPageState();
}

class _AgentDashboardPageState extends State<AgentDashboardPage> {
  static const storage = FlutterSecureStorage();
  static const loginFlagKey = 'tombrian_logged_in';

  bool loading = true;
  String userName = 'Agent';
  String balance = '0.00';
  int referralCount = 0;

  @override
  void initState() {
    super.initState();
    loadAgentData();
  }

  Future<void> loadAgentData() async {
    final client = Supabase.instance.client;
    final user = client.auth.currentUser;

    if (user == null) {
      if (mounted) setState(() => loading = false);
      return;
    }

    try {
      final profile = await client
          .from('profiles')
          .select('full_name, role, agent_approved')
          .eq('id', user.id)
          .maybeSingle();

      final role = profile?['role']?.toString().toLowerCase();
      final approved = profile?['agent_approved'] == true;

      // This page is reserved for approved agents.
      if (role != 'agent' || !approved) {
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const HomePage()),
          (_) => false,
        );
        return;
      }

      try {
        final balanceRow = await client
            .from('balances')
            .select('balance')
            .eq('user_id', user.id)
            .maybeSingle();

        balance = (balanceRow?['balance'] ?? 0).toString();
      } catch (_) {}

      try {
        final referrals = await client
            .from('referrals')
            .select('id')
            .eq('referrer_id', user.id);
        referralCount = (referrals as List).length;
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        userName = (profile?['full_name'] ?? 'Agent').toString().trim();
        if (userName.isEmpty) userName = 'Agent';
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not load Agent Dashboard: $e')),
      );
    }
  }

  void openPage(Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => page),
    );
  }

  Future<void> logout() async {
    await clientSignOut();
    if (!mounted) return;

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginPage()),
      (_) => false,
    );
  }

  Future<void> clientSignOut() async {
    await Supabase.instance.client.auth.signOut();
    await storage.delete(key: loginFlagKey);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Agent Dashboard'),
        actions: [
          IconButton(
            onPressed: loadAgentData,
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: logout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadAgentData,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'TomBrian Agent',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Jambo, $userName 👋',
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF17233D),
                    Color(0xFF0D111C),
                  ],
                ),
                border: Border.all(
                  color: const Color(0x44D9A441),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Agent balance',
                    style: TextStyle(color: Colors.white60),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'KES $balance',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Dream • Work • Achieve',
                    style: TextStyle(
                      color: Color(0xFFD9A441),
                      letterSpacing: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Agent actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ActionCard(
                    icon: Icons.phone_android,
                    title: 'Sell Airtime',
                    onTap: () => openPage(const SellAirtimePage()),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ActionCard(
                    icon: Icons.add_card,
                    title: 'Top Up',
                    onTap: () => openPage(const TopUpPage()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ActionCard(
                    icon: Icons.account_balance_wallet,
                    title: 'Withdraw',
                    onTap: () => openPage(const WithdrawPage()),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ActionCard(
                    icon: Icons.group_add_outlined,
                    title: 'Invite',
                    onTap: () => openPage(const ReferralPage()),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.people_outline,
                  color: Color(0xFFD9A441),
                ),
                title: const Text('People referred'),
                subtitle: const Text(
                  'Customers registered through your invite link.',
                ),
                trailing: Text(
                  '$referralCount',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.support_agent),
                title: const Text('Support Center'),
                subtitle: const Text('Get help from TomBrian Customer Care.'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => openPage(const SupportPage()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AdminCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const AdminCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding:
            const EdgeInsets.all(12),
        child: Column(
          children: [
            Icon(
              icon,
              size: 28,
            ),
            const SizedBox(
              height: 8,
            ),
            Text(
              value,
              style:
                  const TextStyle(
                fontSize: 20,
                fontWeight:
                    FontWeight.bold,
              ),
            ),
            const SizedBox(
              height: 4,
            ),
            Text(
              title,
              textAlign:
                  TextAlign.center,
              style:
                  const TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> _clearLoginFlag() async {
  const storage =
      FlutterSecureStorage();

  await storage.delete(
    key: 'tombrian_logged_in',
  );
}
